<?php

/*
 * Plugin Name: WordPressLeaf Features
 * Plugin URI: http://www.wordpressleaf.com
 * Description: Advanced Features for WordPressLeaf Theme
 * Author: WordPressLeaf
 * Version: 1.0.2
 * Author URI: http://www.wordpressleaf.com
 * Text Domain: tmm_theme_features
*/

class TMM_Theme_Features {


	protected static $instance = null;

	public static $slug = 'tmm_theme_features';

	private function __construct() {

		/* Register custom post types and taxonomies */
		$this->register_post_types();

		/* Add elements to <head> section (tracking code) */
		$this->add_wp_head_elements();
	}

	private function add_wp_head_elements() {

		if (class_exists('TMM')) {
			add_action('wp_head', array(__CLASS__, 'add_tracking_code'), PHP_INT_MAX);
			add_filter('tmm_add_general_theme_option', array(__CLASS__, 'add_tracking_code_option'));
		}

	}

	public static function add_tracking_code_option($options) {

		if (is_array($options)) {
			$options['tracking_code'] = array(
				'title' => __('跟踪代码', self::$slug),
				'type' => 'textarea',
				'default_value' => '',
				'description' => __('在此插入你的百度统计（或其他）跟踪代码。它将添加到您的主题中的</HEAD>标签之前。', self::$slug),
				'custom_html' => ''
			);
		}

		return $options;
	}

	public static function add_tracking_code() {
		echo TMM::get_option("tracking_code");
	}

	private function register_post_types() {

		/*
		 * Register Slidergroup Post Type
		 */

		if (class_exists('TMM_Slider')) {

			$cpt_name = isset(TMM_Slider::$slug) ? TMM_Slider::$slug : 'slidergroup';

			register_post_type($cpt_name, array(
				'labels' => array(
					'name' => __('主题幻灯片', self::$slug),
					'singular_name' => __('分组', self::$slug),
					'add_new' => __('添加新的', self::$slug),
					'add_new_item' => __('添加新的幻灯片分组', self::$slug),
					'edit_item' => __('编辑幻灯片分组', self::$slug),
					'new_item' => __('新的幻灯片分组', self::$slug),
					'view_item' => __('查看幻灯片分组', self::$slug),
					'search_items' => __('搜索幻灯片分组', self::$slug),
					'not_found' => __('没有找到幻灯片分组', self::$slug),
					'not_found_in_trash' => __('在回收站中没有找到幻灯片分组', self::$slug),
					'parent_item_colon' => ''
				),
				'public' => false,
				'archive' => false,
				'exclude_from_search' => false,
				'publicly_queryable' => false,
				'show_ui' => true,
				'query_var' => true,
				'capability_type' => 'post',
				'has_archive' => false,
				'hierarchical' => true,
				'menu_position' => null,
				'supports' => array('title', 'thumbnail'),
				'rewrite' => array('slug' => $cpt_name),
				'show_in_admin_bar' => false,
				'menu_icon' => 'dashicons-images-alt2',
				'taxonomies' => array()
			));

		}

		/*
		 * Register Position Taxonomy and Staff Post Type
		 */

		if (class_exists('TMM_Staff')) {

			$cpt_name = isset(TMM_Staff::$slug) ? TMM_Staff::$slug : 'staff-page';

			register_taxonomy("position", array($cpt_name), array(
				"hierarchical" => true,
				"labels" => array(
					'name' => __('位置', self::$slug),
					'singular_name' => __('位置', self::$slug),
					'add_new' => __('添加新的', self::$slug),
					'add_new_item' => __('添加新的位置', self::$slug),
					'edit_item' => __('编辑位置', self::$slug),
					'new_item' => __('新的位置', self::$slug),
					'view_item' => __('查看位置', self::$slug),
					'search_items' => __('搜索位置', self::$slug),
					'not_found' => __('没有找到位置', self::$slug),
					'not_found_in_trash' => __('在回收站中没有找到位置', self::$slug),
					'parent_item_colon' => ''
				),
				"singular_label" => __("Position", self::$slug),
				"rewrite" => true,
				'show_in_nav_menus' => false,
			));

			register_post_type($cpt_name, array(
				'labels' => array(
					'name' => __('员工', self::$slug),
					'singular_name' => __('员工', self::$slug),
					'add_new' => __('添加新的', self::$slug),
					'add_new_item' => __('添加新的员工', self::$slug),
					'edit_item' => __('编辑员工', self::$slug),
					'new_item' => __('新员工', self::$slug),
					'view_item' => __('查看员工', self::$slug),
					'search_items' => __('在员工中搜索', self::$slug),
					'not_found' => __('什么都没有找到', self::$slug),
					'not_found_in_trash' => __('在回收站中什么都没有找到', self::$slug),
					'parent_item_colon' => ''
				),
				'public' => false,
				'archive' => true,
				'exclude_from_search' => false,
				'publicly_queryable' => true,
				'show_ui' => true,
				'query_var' => true,
				'capability_type' => 'post',
				'has_archive' => true,
				'hierarchical' => true,
				'menu_position' => null,
				'supports' => array('title', 'thumbnail', 'excerpt'),
				'rewrite' => array('slug' => $cpt_name),
				'show_in_admin_bar' => true,
				'taxonomies' => array('position'), // this is IMPORTANT
				'menu_icon' => 'dashicons-businessman'
			));

		}

		/*
		 * Register Testimonials Taxonomy and Testimonial Post Type
		 */

		if (class_exists('TMM_Testimonial')) {

			$cpt_name = isset(TMM_Testimonial::$slug) ? TMM_Testimonial::$slug : 'tmonials';

			register_post_type($cpt_name, array(
				'labels' => array(
					'name' => __('证书', self::$slug),
					'singular_name' => __('证书', self::$slug),
					'add_new' => __('添加新的', self::$slug),
					'add_new_item' => __('添加新的证书', self::$slug),
					'edit_item' => __('编辑证书', self::$slug),
					'new_item' => __('新证书', self::$slug),
					'view_item' => __('查看新证书', self::$slug),
					'search_items' => __('搜索证书', self::$slug),
					'not_found' => __('没有找到证书', self::$slug),
					'not_found_in_trash' => __('在回收站中没有找到证书', self::$slug),
					'parent_item_colon' => ''
				),
				'public' => false,
				'exclude_from_search' => true,
				'publicly_queryable' => true,
				'show_ui' => true,
				'query_var' => true,
				'capability_type' => 'post',
				'has_archive' => true,
				'hierarchical' => true,
				'menu_position' => null,
				'supports' => array('title', 'editor', 'thumbnail'),
				'rewrite' => array('slug' => $cpt_name),
				'show_in_admin_bar' => true,
				'menu_icon' => 'dashicons-edit'
			));

		}

		/*
		 * Register Subscriber Post Type
		 */

		if (class_exists('TMM_Mail_Subscription')) {

			$cpt_name = isset(TMM_Mail_Subscription::$slug) ? TMM_Mail_Subscription::$slug : 'email_subscriber';

			register_post_type($cpt_name, array(
				'labels' => array(
					'name' => __('订阅者', self::$slug),
					'singular_name' => __('订阅者', self::$slug),
					'add_new' => __('添加新的', self::$slug),
					'add_new_item' => __('添加新的订阅者', self::$slug),
					'edit_item' => __('编辑订阅者', self::$slug),
					'new_item' => __('新的订阅者', self::$slug),
					'view_item' => __('查看订阅者', self::$slug),
					'search_items' => __('搜索订阅者', self::$slug),
					'not_found' => __('没有找到订阅者', self::$slug),
					'not_found_in_trash' => __('在回收站中没有找到订阅者', self::$slug),
					'parent_item_colon' => ''
				),
				'public' => false,
				'exclude_from_search' => true,
				'publicly_queryable' => true,
				'show_ui' => true,
				'query_var' => true,
				'capability_type' => 'post',
				'has_archive' => true,
				'hierarchical' => true,
				'menu_position' => null,
				'supports' => array('title'),
				'rewrite' => array('slug' => $cpt_name),
				'show_in_admin_bar' => true,
				'menu_icon' => 'dashicons-email'
			));

		}

		/*
		 * Register Gallery Taxonomy and Gallery Post Type
		 */

		if (class_exists('TMM_Gallery')) {

			$cpt_name = isset(TMM_Gallery::$slug) ? TMM_Gallery::$slug : 'gall';

			register_taxonomy("gallery-category", array($cpt_name), array(
				"hierarchical" => true,
				"labels" => array(
					'name' => __('相册分类', self::$slug),
					'singular_name' => __('相册分类', self::$slug),
					'add_new' => __('添加新的', self::$slug),
					'add_new_item' => __('添加新的相册分类', self::$slug),
					'edit_item' => __('编辑相册分类', self::$slug),
					'new_item' => __('新的相册分类', self::$slug),
					'view_item' => __('查看相册分类', self::$slug),
					'search_items' => __('搜索相册分类', self::$slug),
					'not_found' => __('没有找到相册分类', self::$slug),
					'not_found_in_trash' => __('在回收站中没有找到相册分类', self::$slug),
					'parent_item_colon' => ''
				),
				'show_ui' => true,
				'query_var' => true,
				'capability_type' => 'page',
				'has_archive' => true,
				'hierarchical' => true,
				'show_in_admin_bar' => true,
				"rewrite" => true,
				'show_in_nav_menus' => false,
			));

			register_post_type($cpt_name, array(
				'labels' => array(
					'name' => __('相册', self::$slug),
					'singular_name' => __('相册', self::$slug),
					'add_new' => __('添加新的', self::$slug),
					'add_new_item' => __('添加新的相册', self::$slug),
					'edit_item' => __('编辑相册', self::$slug),
					'new_item' => __('新相册', self::$slug),
					'view_item' => __('查看相册', self::$slug),
					'search_items' => __('搜索相册', self::$slug),
					'not_found' => __('没有找到相册', self::$slug),
					'not_found_in_trash' => __('在回收站中没有找到相册', self::$slug),
					'parent_item_colon' => ''
				),
				'public' => true,
				'exclude_from_search' => false,
				'publicly_queryable' => true,
				'show_ui' => true,
				'query_var' => true,
				'capability_type' => 'post',
				'has_archive' => true,
				'hierarchical' => true,
				'menu_position' => null,
				'supports' => array('title', 'thumbnail'),
				'rewrite' => array('slug' => $cpt_name),
				'show_in_admin_bar' => true,
				'menu_icon' => 'dashicons-format-gallery'
			));

		}

		/*
		 * Register Folio, Clients and Skills Taxonomies and Folio Post Type
		 */

		if (class_exists('TMM_Portfolio')) {

			$cpt_name = isset(TMM_Portfolio::$slug) ? TMM_Portfolio::$slug : 'folio';

			register_taxonomy("clients", array($cpt_name), array(
				"hierarchical" => true,
				"labels" => array(
					'name' => __('客户', self::$slug),
					'singular_name' => __('客户', self::$slug),
					'add_new' => __('添加新的', self::$slug),
					'add_new_item' => __('添加新客户', self::$slug),
					'edit_item' => __('编辑客户', self::$slug),
					'new_item' => __('新客户', self::$slug),
					'view_item' => __('查看客户', self::$slug),
					'search_items' => __('搜索客户', self::$slug),
					'not_found' => __('没有找到客户', self::$slug),
					'not_found_in_trash' => __('在回收站中没有找到客户', self::$slug),
					'parent_item_colon' => ''
				),
				"rewrite" => true,
				'show_in_nav_menus' => false,
				'capabilities' => array('manage_terms'),
				'show_ui' => true
			));

			register_taxonomy("skills", array($cpt_name), array(
				"hierarchical" => true,
				"labels" => array(
					'name' => __('技能', self::$slug),
					'singular_name' => __('技能', self::$slug),
					'add_new' => __('添加新的', self::$slug),
					'add_new_item' => __('添加新的技能', self::$slug),
					'edit_item' => __('编辑技能', self::$slug),
					'new_item' => __('新的技能', self::$slug),
					'view_item' => __('查看技能', self::$slug),
					'search_items' => __('搜索技能', self::$slug),
					'not_found' => __('没有找到技能', self::$slug),
					'not_found_in_trash' => __('在回收站中没有找到技能', self::$slug),
					'parent_item_colon' => ''
				),
				"show_tagcloud" => true,
				'query_var' => true,
				'rewrite' => true,
				'show_in_nav_menus' => false,
				'capabilities' => array('manage_terms'),
				'show_ui' => true
			));

			register_taxonomy("folio-category", array($cpt_name), array(
				"hierarchical" => true,
				"labels" => array(
					'name' => __('分类', self::$slug),
					'singular_name' => __('分类', self::$slug),
					'add_new' => __('添加新的', self::$slug),
					'add_new_item' => __('添加新的分类', self::$slug),
					'edit_item' => __('编辑分类', self::$slug),
					'new_item' => __('新的分类', self::$slug),
					'view_item' => __('查看分类', self::$slug),
					'search_items' => __('搜索分类', self::$slug),
					'not_found' => __('没有找到分类', self::$slug),
					'not_found_in_trash' => __('在回收站中没有找到分类', self::$slug),
					'parent_item_colon' => ''
				),
				"show_tagcloud" => true,
				'query_var' => true,
				'rewrite' => true,
				'show_in_nav_menus' => false,
				'capabilities' => array('manage_terms'),
				'show_ui' => true
			));

			register_post_type($cpt_name, array(
				'labels' => array(
					'name' => __('系列产品', self::$slug),
					'singular_name' => __('系列产品', self::$slug),
					'add_new' => __('添加新的', self::$slug),
					'add_new_item' => __('添加新的系列产品', self::$slug),
					'edit_item' => __('编辑系列产品', self::$slug),
					'new_item' => __('新的系列产品', self::$slug),
					'view_item' => __('查看系列产品', self::$slug),
					'search_items' => __('搜索系列产品', self::$slug),
					'not_found' => __('没有找到系列产品', self::$slug),
					'not_found_in_trash' => __('在回收站中没有找到系列产品', self::$slug),
					'parent_item_colon' => ''
				),
				'public' => true,
				'archive' => true,
				'exclude_from_search' => false,
				'publicly_queryable' => true,
				'show_ui' => true,
				'query_var' => true,
				'capability_type' => 'post',
				'has_archive' => true,
				'hierarchical' => true,
				'menu_position' => null,
				'supports' => array('title', 'editor', 'thumbnail', 'excerpt', 'tags', 'comments'),
				'rewrite' => array('slug' => $cpt_name),
				'show_in_admin_bar' => true,
				'show_in_menu' => true,
				'taxonomies' => array('clients', 'skills', 'post_tag'), // this is IMPORTANT
				'menu_icon' => 'dashicons-portfolio'
			));

		}

	}

	public static function flush_rewrite_rules() {

		self::get_instance();
		flush_rewrite_rules();
	}

	private function __clone() {

	}

	public static function get_instance() {

		if ( self::$instance === null) {
			self::$instance = new self;
		}

		return self::$instance;
	}

	public static function load_plugin_textdomain() {

		load_plugin_textdomain( 'tmm_theme_features', false, plugin_basename( dirname( __FILE__ ) ) . '/languages' );
	}
}

add_action( 'plugins_loaded', array('TMM_Theme_Features', 'load_plugin_textdomain') );

add_action( 'init', array('TMM_Theme_Features', 'get_instance') );

register_activation_hook( __FILE__, array('TMM_Theme_Features', 'flush_rewrite_rules') );
