<?php if (!defined('ABSPATH')) die('No direct access allowed'); ?>
<div id="tmm_shortcode_template" class="tmm_shortcode_template clearfix">

    <div class="one-half">

		<?php
		TMM_Content_Composer::html_option(array(
			'type' => 'text',
			'title' => __('标题', TMM_CC_TEXTDOMAIN),
			'shortcode_field' => 'title',
			'id' => '',
			'default_value' => TMM_Content_Composer::set_default_value('title', '与我们保持联系'),
			'description' => ''
		));
		?>
	</div>

	<div class="one-half">
		<?php
		TMM_Content_Composer::html_option(array(
			'type' => 'textarea',
			'title' => __('描述', TMM_CC_TEXTDOMAIN),
			'shortcode_field' => 'description',
			'default_value' => TMM_Content_Composer::set_default_value('description', '订阅本公司的相关时事信息'),
			'description' => ''
		));
		?>
	</div>
	<div class="one-half">

		<?php
		TMM_Content_Composer::html_option(array(
			'type' => 'text',
			'title' => __('电子邮箱的占位符', TMM_CC_TEXTDOMAIN),
			'shortcode_field' => 'placeholder',
			'default_value' => TMM_Content_Composer::set_default_value('placeholder', '输入您的电子邮箱'),
			'description' => __('在此输入你的电子邮箱占位符。', TMM_CC_TEXTDOMAIN)
		));
		?>

    </div><!--/ .one-half-->

	<div class="one-half">

		<?php
		TMM_Content_Composer::html_option(array(
			'type' => 'checkbox',
			'title' => __('显示邮政编码字段', TMM_CC_TEXTDOMAIN),
			'shortcode_field' => 'zipcode',
			'is_checked' => TMM_Content_Composer::set_default_value('zipcode', true),
			'description' => __('选中此项以显示邮政编码字段。', TMM_CC_TEXTDOMAIN)
		));
		?>

	</div>


</div><!--/ .tmm_shortcode_template->

<!-- --------------------------  PROCESSOR  --------------------------- -->

<script type="text/javascript">
	var shortcode_name = "<?php echo basename(__FILE__, '.php'); ?>";

	jQuery(function() {
		tmm_ext_shortcodes.changer(shortcode_name);
		jQuery("#tmm_shortcode_template .js_shortcode_template_changer").on('keyup change', function() {
			tmm_ext_shortcodes.changer(shortcode_name);
		});

	});
</script>
