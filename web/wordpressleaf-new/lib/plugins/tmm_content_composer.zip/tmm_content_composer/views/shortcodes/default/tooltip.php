<?php
if (!defined('ABSPATH')) exit;

?>
<span class="highlight tooltip"><b><?php echo esc_html($tooltip) ?></b><?php echo esc_html($content) ?></span>