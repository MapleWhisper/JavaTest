<?php if (!defined('ABSPATH')) die('No direct access allowed'); ?>
<span class="dropcap <?php echo esc_attr($type); ?>"><?php echo esc_html($content); ?></span>