<?php if (!defined('ABSPATH')) die('No direct access allowed'); ?>

<div id="tmm_shortcode_template" class="tmm_shortcode_template clearfix">

	<div class="one-half">
		<?php
		TMM_Content_Composer::html_option(array(
			'type' => 'text',
			'title' => __('高', TMM_CC_TEXTDOMAIN),
			'shortcode_field' => 'height',
			'id' => 'height',
			'default_value' => TMM_Content_Composer::set_default_value('height', 200),
			'description' => ''
		));
		?>

	</div><!--/ .one-half-->


	<div class="one-half">
		<?php
		TMM_Content_Composer::html_option(array(
			'type' => 'text',
			'title' => __('宽', TMM_CC_TEXTDOMAIN),
			'shortcode_field' => 'width',
			'id' => 'width',
			'default_value' => TMM_Content_Composer::set_default_value('width', '100%'),
			'description' => ''
		));
		?>
	</div><!--/ .one-half-->


	<div class="one-half">
		<?php
		TMM_Content_Composer::html_option(array(
			'type' => 'select',
			'title' => __('模式', TMM_CC_TEXTDOMAIN),
			'shortcode_field' => 'mode',
			'id' => 'mode',
			'options' => array(
				'map' => __('地图', TMM_CC_TEXTDOMAIN),
				'image' => __('图像', TMM_CC_TEXTDOMAIN),
			),
			'default_value' => TMM_Content_Composer::set_default_value('mode', 'map'),
			'description' => ''
		));
		?>
	</div><!--/ .one-half-->


	<div class="one-half">
		<?php
		TMM_Content_Composer::html_option(array(
			'type' => 'select',
			'title' => __('定位方式', TMM_CC_TEXTDOMAIN),
			'shortcode_field' => 'location_mode',
			'id' => 'location_mode',
			'options' => array(
				'address' => __('地址', TMM_CC_TEXTDOMAIN),
				'coordinates' => __('坐标', TMM_CC_TEXTDOMAIN),
			),
			'default_value' => TMM_Content_Composer::set_default_value('location_mode', 'address'),
			'description' => ''
		));
		?>
	</div><!--/ .one-half-->



	<div class="one-half location_mode_coordinates location_mode_container">
		<?php
		TMM_Content_Composer::html_option(array(
			'type' => 'text',
			'title' => __('标记的纬度', TMM_CC_TEXTDOMAIN),
			'shortcode_field' => 'latitude',
			'id' => 'latitude',
			'default_value' => TMM_Content_Composer::set_default_value('latitude', 40.714623),
			'description' => __('视窗中间的点。如果没有给定和没有定义视窗默认标记，那么将显示世界视图。地址定位模式会自动计算！', TMM_CC_TEXTDOMAIN)
		));
		?>		

	</div><!--/ .one-half-->


	<div class="one-half location_mode_coordinates location_mode_container">

		<?php
		TMM_Content_Composer::html_option(array(
			'type' => 'text',
			'title' => __('标记的经度', TMM_CC_TEXTDOMAIN),
			'shortcode_field' => 'longitude',
			'id' => 'longitude',
			'default_value' => TMM_Content_Composer::set_default_value('longitude', -74.006605),
			'description' => __('视窗中间的点。如果没有给定和没有定义视窗默认标记，那么将显示世界视图。地址定位模式会自动计算！', TMM_CC_TEXTDOMAIN)
		));
		?>
	</div><!--/ .one-half-->


	<div class="one-half location_mode_address location_mode_container">
		<?php
		TMM_Content_Composer::html_option(array(
			'type' => 'text',
			'title' => __('地址', TMM_CC_TEXTDOMAIN),
			'shortcode_field' => 'address',
			'id' => 'address',
			'default_value' => TMM_Content_Composer::set_default_value('address', 'New York'),
			'description' => ''
		));
		?>
	</div><!--/ .one-half-->


	<div class="one-half">
		<?php
		$zoom_array = array();
		for ($i = 1; $i <= 19; $i++) {
			$zoom_array[$i] = $i;
		}
		?>

		<?php
		TMM_Content_Composer::html_option(array(
			'type' => 'select',
			'title' => __('缩放', TMM_CC_TEXTDOMAIN),
			'shortcode_field' => 'zoom',
			'id' => 'zoom',
			'options' => $zoom_array,
			'default_value' => TMM_Content_Composer::set_default_value('zoom', 11),
			'description' => __('缩放值从1到19，其中19是最大的，1是最小的。', TMM_CC_TEXTDOMAIN)
		));
		?>

	</div><!--/ .one-half-->

	<div class="one-half">
		<?php
		TMM_Content_Composer::html_option(array(
			'type' => 'checkbox',
			'title' => __('启用滚轮', TMM_CC_TEXTDOMAIN),
			'shortcode_field' => 'enable_scrollwheel',
			'id' => 'enable_scrollwheel',
			'is_checked' => TMM_Content_Composer::set_default_value('enable_scrollwheel', 0),
			'description' => __('设置为假，则禁止使用你的鼠标滚轮进行缩放。', TMM_CC_TEXTDOMAIN)
		));
		?>
	</div><!--/ .one-half-->

	<div class="one-half">
		<?php
		TMM_Content_Composer::html_option(array(
			'type' => 'select',
			'title' => __('地图类型', TMM_CC_TEXTDOMAIN),
			'shortcode_field' => 'maptype',
			'id' => 'maptype',
			'options' => array(
				'ROADMAP' => __('路线图', TMM_CC_TEXTDOMAIN),
				'SATELLITE' => __('卫星图', TMM_CC_TEXTDOMAIN),
				'HYBRID' => __('混合图', TMM_CC_TEXTDOMAIN),
				'TERRAIN' => __('地形图', TMM_CC_TEXTDOMAIN),
			),
			'default_value' => TMM_Content_Composer::set_default_value('maptype', 'ROADMAP'),
			'description' => ''
		));
		?>	
	</div><!--/ .one-half-->



	<div class="one-half">
		<?php
		TMM_Content_Composer::html_option(array(
			'type' => 'checkbox',
			'title' => __('启用标记', TMM_CC_TEXTDOMAIN),
			'shortcode_field' => 'enable_marker',
			'id' => 'enable_marker',
			'is_checked' => TMM_Content_Composer::set_default_value('enable_marker', 0),
			'description' => __('设置为假，则禁止在视窗中显示标记。', TMM_CC_TEXTDOMAIN)
		));
		?>
	</div><!--/ .one-half-->

	<div class="one-half">
		<?php
		TMM_Content_Composer::html_option(array(
			'type' => 'checkbox',
			'title' => __('启用弹出窗口', TMM_CC_TEXTDOMAIN),
			'shortcode_field' => 'enable_popup',
			'id' => 'enable_popup',
			'is_checked' => TMM_Content_Composer::set_default_value('enable_popup', 0),
			'description' => __('如果为真，当地图完成加载时，此标记的信息窗口将会显示。如果HTML是空的，这个选项将被忽略。', TMM_CC_TEXTDOMAIN)
		));
		?>

	</div><!--/ .one-half-->

	<div class="one-half">
		<?php
		TMM_Content_Composer::html_option(array(
			'type' => 'checkbox',
			'title' => __('标记可拖动', TMM_CC_TEXTDOMAIN),
			'shortcode_field' => 'marker_is_draggable',
			'id' => 'marker_is_draggable',
			'is_checked' => TMM_Content_Composer::set_default_value('marker_is_draggable', 0),
			'description' => __('设置标记拖动', TMM_CC_TEXTDOMAIN)
		));
		?>		
	</div><!--/ .one-half-->

	<div class="one-half">
		<?php
		TMM_Content_Composer::html_option(array(
			'type' => 'textarea',
			'title' => __('Html内容', TMM_CC_TEXTDOMAIN),
			'shortcode_field' => 'content',
			'id' => '',
			'default_value' => TMM_Content_Composer::set_default_value('content', ''),
			'description' => ''
		));
		?>
	</div><!--/ .one-half--> 

</div>

<!-- --------------------------  PROCESSOR  --------------------------- -->

<script type="text/javascript">
	var shortcode_name = "<?php echo basename(__FILE__, '.php'); ?>";

	jQuery(function() {

		var $mode = jQuery('select#mode'),
				$input = jQuery('input[type=text]#width');

		var checkMode = function(mode) {
			if (mode.children(':selected').val() == 'map') {
				$input.prop({
					"disabled": true
				}).css('background-color', '#eee');
			} else {
				$input.prop({
					"disabled": false
				}).css('background-color', '#fff');
			}
		};

		checkMode($mode);

		$mode.on('change', function() {
			checkMode(jQuery(this));
		});

		tmm_ext_shortcodes.changer(shortcode_name);
		jQuery("#tmm_shortcode_template .js_shortcode_template_changer").on('keyup change', function() {
			tmm_ext_shortcodes.changer(shortcode_name);
		});

	});
</script>