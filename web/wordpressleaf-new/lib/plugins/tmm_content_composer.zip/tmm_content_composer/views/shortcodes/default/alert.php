<?php if (!defined('ABSPATH')) die('No direct access allowed'); ?>
<p class="<?php echo esc_attr($type); ?>"><?php echo esc_html($content); ?></p>