<?php if (!defined('ABSPATH')) die('No direct access allowed'); ?>
<?php
$style = $content;
?>
<div class="clear"></div>
<div class="<?php echo esc_attr($style); ?>"></div>