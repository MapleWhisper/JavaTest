<?php if (!defined('ABSPATH')) die('No direct access allowed'); ?>
<div id="tmm_shortcode_template" class="tmm_shortcode_template clearfix">

	<div class="fullwidth">
		<?php
		TMM_Content_Composer::html_option(array(
			'type' => 'upload_video',
			'title' => __('Youtube\Vimeo\优酷\腾讯的链接', TMM_CC_TEXTDOMAIN),
			'shortcode_field' => 'content',
			'id' => '',
			'default_value' => TMM_Content_Composer::set_default_value('content', ''),
			'description' => __('Examples: https://www.youtube.com/watch?v=_EBYf3lYSEg  http://vimeo.com/22439234 或者上传到自己网站的视频', TMM_CC_TEXTDOMAIN)
		));
		?>

	</div><!--/ .one-half-->

	<div class="fullwidth">
		<?php
		TMM_Content_Composer::html_option(array(
			'type' => 'upload',
			'title' => __('自己网站视频的封面图片', TMM_CC_TEXTDOMAIN),
			'shortcode_field' => 'cover_image',
			'id' => '',
			'default_value' => TMM_Content_Composer::set_default_value('cover_image', ''),
			'description' => ''
		));
		?>

		<?php
		TMM_Content_Composer::html_option(array(
			'type' => 'checkbox',
			'title' => __('仅在手机上显示封面图片', TMM_CC_TEXTDOMAIN),
			'shortcode_field' => 'cover_image_on_mobiles',
			'id' => 'cover_image_on_mobiles',
			'is_checked' => TMM_Content_Composer::set_default_value('cover_image_on_mobiles', 1),
			'description' => __('仅在手机上显示封面图片', TMM_CC_TEXTDOMAIN)
		));
		?>
	</div><!--/ .one-half-->

	<div class="one-half">
		<?php
		TMM_Content_Composer::html_option(array(
			'type' => 'text',
			'title' => __('宽', TMM_CC_TEXTDOMAIN),
			'shortcode_field' => 'width',
			'id' => 'width',
			'default_value' => TMM_Content_Composer::set_default_value('width', ''),
			'description' => ''
		));
		?>

	</div>

	<div class="one-half">
		<?php
		TMM_Content_Composer::html_option(array(
			'type' => 'text',
			'title' => __('高', TMM_CC_TEXTDOMAIN),
			'shortcode_field' => 'height',
			'id' => 'height',
			'default_value' => TMM_Content_Composer::set_default_value('height', ''),
			'description' => ''
		));
		?>

	</div><!--/ .one-half-->

</div>

<!-- --------------------------  PROCESSOR  --------------------------- -->
<script type="text/javascript">


	var shortcode_name = "<?php echo basename(__FILE__, '.php'); ?>";
	jQuery(function() {
		tmm_ext_shortcodes.changer(shortcode_name);
		jQuery("#tmm_shortcode_template .js_shortcode_template_changer").on('keyup change', function() {
			tmm_ext_shortcodes.changer(shortcode_name);
		});

	});


</script>

