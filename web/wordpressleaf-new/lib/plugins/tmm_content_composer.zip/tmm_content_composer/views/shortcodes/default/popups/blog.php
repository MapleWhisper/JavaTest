<?php if (!defined('ABSPATH')) die('No direct access allowed'); ?>
<div id="tmm_shortcode_template" class="tmm_shortcode_template clearfix">

	<div class="tabs-holder">

		<ul class="tabs-nav clearfix">

			<li><a href="#"><?php _e( '默认选项', TMM_CC_TEXTDOMAIN ); ?></a></li>
			<li><a href="#"><?php _e( '高级博客选项', TMM_CC_TEXTDOMAIN ); ?></a></li>

		</ul>

		<div class="tabs-container clearfix">

			<div class="tab-content">

				<div class="one-half">
					<?php
					TMM_Content_Composer::html_option(array(
						'type' => 'select',
						'title' => __('博客类型', TMM_CC_TEXTDOMAIN),
						'shortcode_field' => 'blog_type',
						'id' => 'blog_type',
						'options' => TMM_Content_Composer::get_blog_type(),
						'default_value' => TMM_Content_Composer::set_default_value('blog_type', 'blog-classic'),
						'description' => __('为显示的文章选择必要的布局。', TMM_CC_TEXTDOMAIN)
					));
					?>
				</div>

				<div class="one-half option-default">
					<?php
					TMM_Content_Composer::html_option(array(
						'type' => 'select',
						'title' => __('文章出现时的效果', TMM_CC_TEXTDOMAIN),
						'shortcode_field' => 'post_appearing_effect',
						'default_value' =>  TMM_Content_Composer::set_default_value('post_appearing_effect', 'elementFade'),
						'options' => array(
							'none' => __('无', TMM_CC_TEXTDOMAIN),
							'elementFade' => __('元素淡出', TMM_CC_TEXTDOMAIN),
							'opacity' => __('模糊', TMM_CC_TEXTDOMAIN),
							'opacity2xRun' => __('2x运行的模糊', TMM_CC_TEXTDOMAIN),
							'scale' => __('比例', TMM_CC_TEXTDOMAIN),
							'slideRight' => __('右滑', TMM_CC_TEXTDOMAIN),
							'slideLeft' => __('左滑', TMM_CC_TEXTDOMAIN),
							'slideDown' => __('下滑', TMM_CC_TEXTDOMAIN),
							'slideUp' => __('上滑', TMM_CC_TEXTDOMAIN),
							'slideUp2x' => __('上滑2x', TMM_CC_TEXTDOMAIN),
							'extraRadius' => __('扩大半径', TMM_CC_TEXTDOMAIN)
						),
						'description' => __('出现文章的特效。', TMM_CC_TEXTDOMAIN)
					));
					?>
				</div>

				<div class="one-half option-default">
					<?php
					TMM_Content_Composer::html_option(array(
						'type' => 'select',
						'multiple' => true,
						'title' => __('分类', TMM_CC_TEXTDOMAIN),
						'shortcode_field' => 'category',
						'id' => 'category',
						'options' => TMM_Content_Composer::get_post_categories(),
						'default_value' => TMM_Content_Composer::set_default_value('category', ''),
						'description' => ''
					));
					?>

				</div><!--/ .ona-half-->

				<div class="one-half option-default">
					<?php
					TMM_Content_Composer::html_option(array(
						'type' => 'select',
						'multiple' => true,
						'title' => __('标签', TMM_CC_TEXTDOMAIN),
						'shortcode_field' => 'tag',
						'id' => 'tag',
						'options' => TMM_Content_Composer::get_post_tags(),
						'default_value' => TMM_Content_Composer::set_default_value('tag', ''),
						'description' => ''
					));
					?>

				</div><!--/ .ona-half-->

				<div class="one-half option-columns">

					<?php
					TMM_Content_Composer::html_option(array(
						'type' => 'select',
						'title' => __('布局', TMM_CC_TEXTDOMAIN),
						'shortcode_field' => 'columns',
						'id' => '',
						'options' => array(
							'fullwidth' => __('全宽', TMM_CC_TEXTDOMAIN),
							'2' => __('2 列', TMM_CC_TEXTDOMAIN),
							'3' => __('3 列', TMM_CC_TEXTDOMAIN),
							'4' => __('4 列', TMM_CC_TEXTDOMAIN)
						),
						'default_value' => TMM_Content_Composer::set_default_value('columns', '2'),
						'description' => ''
					));
					?>

				</div><!--/ .one-half-->

				<div class="one-half option-default">

					<?php
					TMM_Content_Composer::html_option(array(
						'type' => 'select',
						'title' => __('排序方式', TMM_CC_TEXTDOMAIN),
						'shortcode_field' => 'orderby',
						'id' => 'orderby',
						'options' => TMM_Content_Composer::get_post_sort_array(),
						'default_value' => TMM_Content_Composer::set_default_value('orderby', 'date'),
						'description' => ''
					));
					?>

				</div><!--/ .ona-half-->

				<div class="one-half option-default">
					<?php
					TMM_Content_Composer::html_option(array(
						'type' => 'select',
						'title' => __('排序', TMM_CC_TEXTDOMAIN),
						'shortcode_field' => 'order',
						'id' => 'order',
						'options' => array(
							'DESC' => __('降序', TMM_CC_TEXTDOMAIN),
							'ASC' => __('升序', TMM_CC_TEXTDOMAIN),
						),
						'default_value' => TMM_Content_Composer::set_default_value('order', 'DESC'),
						'description' => ''
					));
					?>
				</div><!--/ .ona-half-->

				<div class="one-half option-default">
					<?php
					TMM_Content_Composer::html_option(array(
						'type' => 'text',
						'title' => __('每页文章数', TMM_CC_TEXTDOMAIN),
						'shortcode_field' => 'posts_per_page',
						'id' => 'posts_per_page',
						'default_value' => TMM_Content_Composer::set_default_value('posts_per_page', 5),
						'description' => ''
					));
					?>

				</div><!--/ .ona-half-->

				<div class="one-half option-masonry">
					<?php
					TMM_Content_Composer::html_option(array(
						'type' => 'text',
						'title' => __('每次加载文章数', TMM_CC_TEXTDOMAIN),
						'shortcode_field' => 'posts_per_load',
						'id' => 'posts_per_load',
						'default_value' => TMM_Content_Composer::set_default_value('posts_per_load', 5),
						'description' => ''
					));
					?>

				</div><!--/ .one-half-->

				<div class="one-half option-default">
					<?php
					TMM_Content_Composer::html_option(array(
						'type' => 'text',
						'title' => __('文章', TMM_CC_TEXTDOMAIN),
						'shortcode_field' => 'posts',
						'id' => 'posts',
						'default_value' => TMM_Content_Composer::set_default_value('posts', ''),
						'description' => __('例如： 56,73,119.它具有最高的优先级！', TMM_CC_TEXTDOMAIN)
					));
					?>

				</div><!--/ .ona-half-->

				<div class="one-half option-default">
					<?php
					TMM_Content_Composer::html_option(array(
						'type' => 'select',
						'title' => __('排除文章', TMM_CC_TEXTDOMAIN),
						'shortcode_field' => 'exclude_post_types',
						'id' => 'exclude_posts',
						'options' => array(
							'none' => __('无', TMM_CC_TEXTDOMAIN),
							'post-with-image' => __('带特色图片的文章', TMM_CC_TEXTDOMAIN),
							'post-without-image' => __('不带特色图片的文章', TMM_CC_TEXTDOMAIN),
						),
						'default_value' => TMM_Content_Composer::set_default_value('exclude_post_types', 'none'),
						'description' => __('选择不包含在当前查询中的文章格式。', TMM_CC_TEXTDOMAIN)
					));
					?>

				</div><!--/ .ona-half-->

				<div class="one-half option-default">
					<?php
					TMM_Content_Composer::html_option(array(
						'type' => 'select',
						'title' => __('排除文章格式', TMM_CC_TEXTDOMAIN),
						'shortcode_field' => 'exclude_post_formats',
						'id' => 'exclude_post_formats',
						'multiple' => true,
						'options' => array(
							'none' => __('无', TMM_CC_TEXTDOMAIN),
							'post-format-gallery' => __('相册文章', TMM_CC_TEXTDOMAIN),
							'post-format-quote' => __('引用文章', TMM_CC_TEXTDOMAIN),
							'post-format-video' => __('视频文章', TMM_CC_TEXTDOMAIN),
							'post-format-audio' => __('音频文章', TMM_CC_TEXTDOMAIN)
						),
						'default_value' => TMM_Content_Composer::set_default_value('exclude_post_formats', 'none'),
						'description' => __('选择不包含在当前查询中的文章格式。', TMM_CC_TEXTDOMAIN)
					));
					?>

				</div><!--/ .ona-half-->

				<div class="one-half">
					<?php
					TMM_Content_Composer::html_option(array(
						'type' => 'text',
						'title' => __('标题的字符数', TMM_CC_TEXTDOMAIN),
						'shortcode_field' => 'title_symbols',
						'id' => 'posts',
						'default_value' => TMM_Content_Composer::set_default_value('title_symbols', '60'),
						'description' => __('根据您想要的字符数截断标题。', TMM_CC_TEXTDOMAIN)
					));
					?>
				</div><!--/ .ona-half-->

				<div class="one-half option-excerpt">
					<?php
					TMM_Content_Composer::html_option(array(
						'type' => 'checkbox',
						'title' => __('显示/隐藏文章摘要', TMM_CC_TEXTDOMAIN),
						'shortcode_field' => 'show_excerpt',
						'id' => 'show_excerpt',
						'is_checked' => TMM_Content_Composer::set_default_value('show_excerpt', 1),
						'description' => __('如果选中，文章摘要将根据布局来显示。', TMM_CC_TEXTDOMAIN)
					));
					?>
				</div><!--/ .ona-half-->

				<div class="one-half option-excerpt">
					<?php
					TMM_Content_Composer::html_option(array(
						'type' => 'text',
						'title' => __('摘要的字符数', TMM_CC_TEXTDOMAIN),
						'shortcode_field' => 'excerpt_symbols',
						'id' => 'excerpt_symbols',
						'default_value' => TMM_Content_Composer::set_default_value('excerpt_symbols', '60'),
						'description' => __('根据您想要的字符数截断摘要。', TMM_CC_TEXTDOMAIN)
					));
					?>
				</div><!--/ .ona-half-->

				<div class="one-half option-default">
					<?php
					TMM_Content_Composer::html_option(array(
						'type' => 'checkbox',
						'title' => __('显示/隐藏分页', TMM_CC_TEXTDOMAIN),
						'shortcode_field' => 'show_pagination',
						'id' => 'show_pagination',
						'is_checked' => TMM_Content_Composer::set_default_value('show_pagination', 0),
						'description' => __('启用分页', TMM_CC_TEXTDOMAIN)
					));
					?>

				</div><!--/ .ona-half-->

				<div class="one-half option-border">
					<?php
					TMM_Content_Composer::html_option(array(
						'type' => 'checkbox',
						'title' => __('显示/隐藏边框底部', TMM_CC_TEXTDOMAIN),
						'shortcode_field' => 'show_border_bottom',
						'id' => 'show_border_bottom',
						'is_checked' => TMM_Content_Composer::set_default_value('show_border_bottom', 1),
						'description' => __('显示/隐藏边框底部', TMM_CC_TEXTDOMAIN)
					));
					?>

				</div><!--/ .ona-half-->

				<div class="one-half option-masonry">
					<?php
					TMM_Content_Composer::html_option(array(
						'type' => 'checkbox',
						'title' => __('通过滚动加载文章', TMM_CC_TEXTDOMAIN),
						'shortcode_field' => 'load_by_scrolling',
						'id' => 'load_by_scrolling',
						'is_checked' => TMM_Content_Composer::set_default_value('load_by_scrolling', true),
						'default_value' => TMM_Content_Composer::set_default_value('load_by_scrolling', true),
						'description' => ''
					));
					?>
				</div><!--/ .one-half-->

				<div class="one-half option-classic">
					<?php
					TMM_Content_Composer::html_option(array(
						'type' => 'checkbox',
						'title' => __('显示/隐藏标签', TMM_CC_TEXTDOMAIN),
						'shortcode_field' => 'show_tags',
						'id' => 'show_tags',
						'is_checked' => TMM_Content_Composer::set_default_value('show_tags', true),
						'default_value' => TMM_Content_Composer::set_default_value('show_tags', true),
						'description' => ''
					));
					?>
				</div><!--/ .one-half-->

				<div class="one-half option-classic">
					<?php
					TMM_Content_Composer::html_option(array(
						'type' => 'checkbox',
						'title' => __('显示/隐藏作者', TMM_CC_TEXTDOMAIN),
						'shortcode_field' => 'show_author',
						'id' => 'show_author',
						'is_checked' => TMM_Content_Composer::set_default_value('show_author', true),
						'default_value' => TMM_Content_Composer::set_default_value('show_author', true),
						'description' => ''
					));
					?>
				</div><!--/ .one-half-->

			</div>

			<div class="tab-content">

				<div class="one-half">
					<?php
					TMM_Content_Composer::html_option(array(
						'type' => 'text',
						'title' => __('图像的不透明度', TMM_CC_TEXTDOMAIN),
						'shortcode_field' => 'image_opacity',
						'id' => 'posts',
						'default_value' => TMM_Content_Composer::set_default_value('image_opacity', '0.3'),
						'description' => __('悬停时图像不透明度', TMM_CC_TEXTDOMAIN)
					));
					?>

				</div><!--/ .ona-half-->

				<div class="one-half">
					<?php
					TMM_Content_Composer::html_option(array(
						'type' => 'color',
						'title' => __('图像背景', TMM_CC_TEXTDOMAIN),
						'shortcode_field' => 'image_background',
						'id' => 'image_background',
						'default_value' => TMM_Content_Composer::set_default_value('image_background', '#272729'),
						'description' => '',
						'display' => 1
					));
					?>

				</div><!--/ .ona-half-->

			</div>

		</div>

	</div>

</div>

<!-- --------------------------  PROCESSOR  --------------------------- -->
<script type="text/javascript">
	var shortcode_name = "<?php echo basename(__FILE__, '.php'); ?>";

	jQuery(function() {
		tmm_ext_shortcodes.changer(shortcode_name);
		jQuery("#tmm_shortcode_template .js_shortcode_template_changer").on('keyup change', function() {
			tmm_ext_shortcodes.changer(shortcode_name);
		});

		colorizator();

		var blogType = jQuery('#blog_type').val(),
			optionBorder = jQuery('.option-border'),
			optionMasonry = jQuery('.option-masonry'),
			optionDefault = jQuery('.option-default'),
			optionExcerpt = jQuery('.option-excerpt'),
			optionClassic = jQuery('.option-classic'),
			showExcerpt = jQuery('#show_excerpt'),
			ExcerptSymbols = jQuery('#excerpt_symbols');

		cahangeExcerpt(showExcerpt.is(':checked'));

		showExcerpt.life('change', function(){
			var val = jQuery(this).is(':checked');
			cahangeExcerpt(val);
		});

		function cahangeExcerpt(val){
			if (val){
				ExcerptSymbols.attr('disabled', false).css('background-color', '#fff');
			}else{
				ExcerptSymbols.attr('disabled', true).css('background-color', '#eee');
			}

		}

		changeBlogType(blogType);

		jQuery('#blog_type').on('change', function(){
			var $this = jQuery(this),
				val = $this.val();

			changeBlogType(val);

		});

		function changeBlogType(val){
			switch (val){
				case 'blog-classic':
					optionDefault.slideDown(300);
					optionMasonry.slideUp(300);
					optionBorder.slideDown(300);
					optionExcerpt.slideDown(300);
					optionClassic.slideDown(300);
					break;
				case 'blog-classic-alt':
					optionDefault.slideDown(300);
					optionMasonry.slideUp(300);
					optionBorder.slideDown(300);
					optionExcerpt.slideDown(300);
					optionClassic.slideUp(300);
					break;
				case 'blog-masonry':
					optionDefault.slideUp(300);
					optionMasonry.slideDown(300);
					optionBorder.slideUp(300);
					optionExcerpt.slideDown(300);
					optionClassic.slideUp(300);
					break;
				case 'blog-second':
					optionDefault.slideDown(300);
					optionMasonry.slideUp(300);
					optionBorder.slideDown(300);
					optionExcerpt.slideUp(300);
					optionClassic.slideUp(300);
					break;
				case 'blog-third':
					optionDefault.slideDown(300);
					optionMasonry.slideUp(300);
					optionBorder.slideUp(300);
					optionExcerpt.slideUp(300);
					optionClassic.slideUp(300);
					break;
				case 'blog-fourth':
					optionDefault.slideDown(300);
					optionMasonry.slideUp(300);
					optionBorder.slideDown(300);
					optionExcerpt.slideUp(300);
					optionClassic.slideUp(300);
					break;
				case 'blog-fifth':
					optionDefault.slideDown(300);
					optionMasonry.slideUp(300);
					optionBorder.slideDown(300);
					optionExcerpt.slideUp(300);
					optionClassic.slideUp(300);
					break;	
				default:
					optionDefault.slideDown(300);
					optionMasonry.slideUp(300);
					optionBorder.slideDown(300);
					optionExcerpt.slideDown(300);
					optionClassic.slideUp(300);
					break;
			}
		}

		if (jQuery('.tabs-holder').length) {

			var $tabsHolder = jQuery('.tabs-holder');

			$tabsHolder.each(function (i, val) {

				var $tabsNav = jQuery('.tabs-nav', val),
					eventtype = 'click';

				$tabsNav.each(function () {
					jQuery(this).next().children('.tab-content').first().stop(true, true).show();
					jQuery(this).children('li').first().addClass('active').stop(true, true).show();
				});

				$tabsNav.on(eventtype, 'a', function (e) {
					var $this = jQuery(this).parent('li'),
						$index = $this.index();
					$this.siblings().removeClass('active').end().addClass('active');
					$this.parent().next().children('.tab-content').stop(true, true).hide().eq($index).stop(true, true).fadeIn(250);
					e.preventDefault();
				});
			});
		}

	});
</script>



