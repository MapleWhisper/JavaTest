<?php if (!defined('ABSPATH')) die('No direct access allowed'); ?>
<span class="highlight"><?php echo esc_html($content); ?></span>