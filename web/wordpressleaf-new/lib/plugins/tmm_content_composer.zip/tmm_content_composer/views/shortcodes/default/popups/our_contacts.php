<?php if (!defined('ABSPATH')) die('No direct access allowed'); ?>
<div id="tmm_shortcode_template" class="tmm_shortcode_template clearfix">

    <div class="fullwidth">

		<?php
		TMM_Content_Composer::html_option(array(
			'type' => 'text',
			'title' => __('输入地址', TMM_CC_TEXTDOMAIN),
			'shortcode_field' => 'content',
			'id' => '',
			'default_value' => TMM_Content_Composer::set_default_value('content', ''),
			'description' => ''
		));
		?>

		<?php
		TMM_Content_Composer::html_option(array(
			'type' => 'text',
			'title' => __('输入电话', TMM_CC_TEXTDOMAIN),
			'shortcode_field' => 'phone',
			'id' => 'phone',
			'default_value' => TMM_Content_Composer::set_default_value('phone', ''),
			'description' => ''
		));
		?>

		<?php
		TMM_Content_Composer::html_option(array(
			'type' => 'text',
			'title' => __('输入电子邮箱', TMM_CC_TEXTDOMAIN),
			'shortcode_field' => 'email',
			'id' => 'email',
			'default_value' => TMM_Content_Composer::set_default_value('email', ''),
			'description' => ''
		));
		?>

		<?php
		TMM_Content_Composer::html_option(array(
			'type' => 'textarea',
			'title' => __('工作日信息', TMM_CC_TEXTDOMAIN),
			'shortcode_field' => 'working_days',
			'id' => 'working_days',
			'default_value' => TMM_Content_Composer::set_default_value('working_days', ''),
			'description' => __('在此输入你的工作日信息。', TMM_CC_TEXTDOMAIN)
		));
		?>

		<?php
		$days = array(
			'Monday' => __('周一', TMM_CC_TEXTDOMAIN),
			'Tuesday' => __('周二', TMM_CC_TEXTDOMAIN),
			'Wednesday' => __('周三', TMM_CC_TEXTDOMAIN),
			'Thursday' => __('周四', TMM_CC_TEXTDOMAIN),
			'Friday' => __('周五', TMM_CC_TEXTDOMAIN),
			'Saturday' => __('周六', TMM_CC_TEXTDOMAIN),
			'Sunday' => __('周日', TMM_CC_TEXTDOMAIN)
		);
		TMM_Content_Composer::html_option(array(
			'type' => 'select',
			'title' => __('休息日', TMM_CC_TEXTDOMAIN),
			'shortcode_field' => 'closed_days',
			'id' => 'closed_days',
			'options' => $days,
			'multiple' => true,
			'default_value' => TMM_Content_Composer::set_default_value('closed_days', 'sunday'),
			'description' => __('按住Ctrl键并单击列表中的项选择它们', TMM_CC_TEXTDOMAIN)
		));
		?>


    </div><!--/ .fullwidth-->

</div><!--/ .tmm_shortcode_template->

<!-- --------------------------  PROCESSOR  --------------------------- -->

<script type="text/javascript">
	var shortcode_name = "<?php echo basename(__FILE__, '.php'); ?>";

	jQuery(function() {
		tmm_ext_shortcodes.changer(shortcode_name);
		jQuery("#tmm_shortcode_template .js_shortcode_template_changer").on('keyup change', function() {
			tmm_ext_shortcodes.changer(shortcode_name);
		});

	});
</script>
